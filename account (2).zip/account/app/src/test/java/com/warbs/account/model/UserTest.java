package com.warbs.account.model;

import org.junit.Test;

import static org.junit.Assert.*;

public class UserTest {

    @Test
    public void getUsername() {
        String username = "me";
        String email = "me@me.com";
        String password = "12345678";
        String expected = "me";
       User user = new User(username, email, password);
       assertEquals(user.getUsername(), expected);

    }

    @Test
    public void setUsername() {
        String username = "me";
        String email = "me@me.com";
        String password = "12345678";
        String expected = "you";
        String str = "you";
        User user = new User(username, email, password);
        user.setUsername(str);
        assertEquals(user.getUsername(), expected);
    }

    @Test
    public void getPassword() {
        String username = "me";
        String email = "me@me.com";
        String password = "12345678";
        String expected = "12345678";

        User user = new User(username, password,email);

        assertEquals(user.getPassword(), expected);
    }

    @Test
    public void setPassword() {
        String username = "me";
        String email = "me@me.com";
        String password = "12345678";
        String expected = "23456789";
        String str = "23456789";
        User user = new User(username, email, password);
        user.setPassword(str);
        assertEquals(user.getPassword(), expected);
    }

    @Test
    public void getEmail() {
        String username = "me";
        String email = "me@me.com";
        String password = "12345678";
        String expected = "me@me.com";
        User user = new User(username, password, email );
        assertEquals(user.getEmail(), expected);
    }

    @Test
    public void setEmail() {
        String username = "me";
        String email = "me@me.com";
        String password = "12345678";
        String expected = "me@gmail.com";
        String str = "me@gmail.com";
        User user = new User(username, password, email);
        user.setEmail(str);
        assertEquals(user.getEmail(), expected);
    }
}