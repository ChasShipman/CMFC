package com.warbs.cmfclogin;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ImageViewHolder> {

    private int[] images;
    public RecyclerAdapter(int[] images) {
        this.images = images;

    }





    @Override
    public ImageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.album, parent, false);
        ImageViewHolder imageViewHolder = new ImageViewHolder(view);


        return imageViewHolder;
    }

    @Override
    public void onBindViewHolder(ImageViewHolder holder, int position) {

        holder.Lennon.setImageResource(images[position]);

    }

    @Override
    public int getItemCount() {
        return images.length;
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder{
        ImageView Lennon;

        private TextView lennon2, lennon3;

        public ImageViewHolder(View itemView) {
            super(itemView);
            Lennon = itemView.findViewById(R.id.lennon);
            lennon2 = itemView.findViewById(R.id.title);
            lennon3 = itemView.findViewById(R.id.edit_date);



            final MediaPlayer play = MediaPlayer.create(itemView.getContext(), R.raw.imagine);
            Lennon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(play.isPlaying())
                    {
                        play.pause();
                    }
                    else {
                        play.start();
                    }
                }
            });

        }


    }
}
