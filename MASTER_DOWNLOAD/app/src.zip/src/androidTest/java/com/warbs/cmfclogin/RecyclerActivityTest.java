package com.warbs.cmfclogin;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class RecyclerActivityTest {

    @Test
    public void onCreate() {
        List<Composition> compList = new ArrayList<>();
        compList.clear();
      //  String expectedTitle = "Enter Sandman";
      //  String expectedDate = "06-16-91";
        Composition comp = new Composition("Enter Sandman", "06-16-91");//, "04-01-19");
        compList.add(comp);
        assertEquals(compList.size(), 1); //testing input item works
        //assert compList.contains(comp); //check that the comp object is in the list
    }
}