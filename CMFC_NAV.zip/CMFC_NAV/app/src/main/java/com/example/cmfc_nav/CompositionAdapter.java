package com.example.cmfc_nav;

/*

ADAPTER CLASS FOR COMPOSITION OBJECT
AUTHOR @CHAS SHIPMAN


 */


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class CompositionAdapter extends
        RecyclerView.Adapter<CompositionAdapter.MyViewHolder> { //made to extend RecyclerView.Adapter

    private List<Composition> compList;

    public class MyViewHolder extends RecyclerView.ViewHolder { //upholds viewholder standards for recycler view
        public TextView title, edit; //create;

        public MyViewHolder(View view) { //constructs each view for recycler
            super(view);
            title =  view.findViewById(R.id.title);
            edit =  view.findViewById(R.id.edit_date);
            //create =   view.findViewById(R.id.create_date);
        }
    }


    public CompositionAdapter(List<Composition> compList) {//constructor
        this.compList = compList;
    }

    @Override
    public CompositionAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) { //inflate the layout
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View compView = inflater.inflate(R.layout.composition_list_row, parent, false);

        return new MyViewHolder(compView);
    }

    @Override
    public void onBindViewHolder(CompositionAdapter.MyViewHolder holder, int position) { //bind data in complist items to viewholder
        Composition comp = compList.get(position);
        holder.title.setText(comp.getTitle());
        holder.edit.setText(comp.getEdit());
       // holder.create.setText(comp.getCreate());
    }

    @Override
    public int getItemCount() { //wrapper for size
        return compList.size();
    }

    public List<Composition> getData() {
        return compList; //wrapper for the complist
    }


    public void removeItem(int position) { //helper for swipe to delete
        compList.remove(position);
        notifyItemRemoved(position);
    }

    public void restoreItem(Composition item, int position) { //helper to undo swipe delete
        compList.add(position, item);
        notifyItemInserted(position);
    }
}
