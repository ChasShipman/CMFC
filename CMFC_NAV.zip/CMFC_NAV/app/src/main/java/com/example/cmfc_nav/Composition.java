package com.example.cmfc_nav;
/*

OBJECT CLASS FOR COMPOSITION ITEM IN RECYCLER VIEW
AUTHOR @CHAS SHIPMAN

 */
public class Composition {
    private String title, edit;//, create; //each item has a title and edit date. scrapped create date


    public Composition(String title, String edit){//, String create) { //constructor
        this.title = title;
        this.edit = edit;
       // this.create = create;
    }

    public String getTitle() { //get the title of a compositon

        return title;
    }

    public void setTitle(String name) { //set the title of a composition

        this.title = name;
    }

  //  public String getCreate() {
//
  //      return create;
  //  }

   // public void setCreate(String create) {
//
  //      this.create = create;
   // }

    public String getEdit() { //get the edit date of a composition

        return edit;
    }

    public void setEdit(String edit) { //set the edit date of a composition

        this.edit = edit;
    }
}

