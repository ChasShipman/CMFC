package com.example.cmfc_nav;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class RecyclerActivityTest {

    @Test
    public void onCreate() {
            List<Composition> compList = new ArrayList<>();
            compList.clear();
            Composition comp = new Composition("Enter Sandman", "06-16-91");//, "04-01-19");
            compList.add(comp); //create a composition and add it to a compList for a recyclerView
            assertEquals(compList.size(), 1); //testing inserting comp object
            assert compList.contains(comp); //check that the comp object is in the list


    }
}