package com.example.cmfc_nav;

import org.junit.Test;

import static org.junit.Assert.*;

public class CompositionTest {

    @Test
    public void getTitle() {
        String str1 = "Test_Song";
        String str2 = "01-01-01";
        String expectedTitle = "Test_Song";
        Composition composition = new Composition(str1, str2);
        assertEquals(composition.getTitle(), expectedTitle);
    }

    @Test
    public void setTitle() {
        String str1 = "Test_Song";
        String str2 = "01-01-01";
        String str3 = "New_Song_Title";
        String expectedTitle = "New_Song_Title";
        Composition composition = new Composition(str1, str2);
        composition.setTitle(str3);
        assertEquals(composition.getTitle(), expectedTitle);
    }

    @Test
    public void getEdit() {
        String str1 = "Test_Song";
        String str2 = "01-01-01";
        String expectedDate = "01-01-01";
        Composition composition = new Composition(str1, str2);
        assertEquals(composition.getEdit(), expectedDate);
    }

    @Test
    public void setEdit() {
        String str1 = "Test_Song";
        String str2 = "01-01-01";
        String str3 = "10-10-10";
        String expectedDate = "10-10-10";
        Composition composition = new Composition(str1, str2);
        composition.setEdit(str3);
        assertEquals(composition.getEdit(), expectedDate);

    }
}