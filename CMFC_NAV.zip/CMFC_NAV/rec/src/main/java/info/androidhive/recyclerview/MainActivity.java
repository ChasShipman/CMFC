package info.androidhive.recyclerview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Composition> compositionList = new ArrayList<>();
    private RecyclerView recyclerView;
    private CompositionAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        mAdapter = new CompositionAdapter(compositionList);

        recyclerView.setHasFixedSize(true);

        // vertical RecyclerView
        // keep movie_list_row.xml width to `match_parent`
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());

        // horizontal RecyclerView
        // keep movie_list_row.xml width to `wrap_content`
        // RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);

        recyclerView.setLayoutManager(mLayoutManager);

        // adding inbuilt divider line
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        // adding custom divider line with padding 16dp
        // recyclerView.addItemDecoration(new MyDividerItemDecoration(this, LinearLayoutManager.HORIZONTAL, 16));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.setAdapter(mAdapter);

        // row click listener
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Composition composition = compositionList.get(position);
                Toast.makeText(getApplicationContext(), composition.getTitle() + " is selected!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        prepareMovieData();
    }

    /**
     * Prepares sample data to provide data set to adapter
     */
    private void prepareMovieData() {
        Composition composition = new Composition("Mad Max: Fury Road", "Action & Adventure", "2015");
        compositionList.add(composition);

        composition = new Composition("Inside Out", "Animation, Kids & Family", "2015");
        compositionList.add(composition);

        composition = new Composition("Star Wars: Episode VII - The Force Awakens", "Action", "2015");
        compositionList.add(composition);

        composition = new Composition("Shaun the Sheep", "Animation", "2015");
        compositionList.add(composition);

        composition = new Composition("The Martian", "Science Fiction & Fantasy", "2015");
        compositionList.add(composition);

        composition = new Composition("Mission: Impossible Rogue Nation", "Action", "2015");
        compositionList.add(composition);

        composition = new Composition("Up", "Animation", "2009");
        compositionList.add(composition);

        composition = new Composition("Star Trek", "Science Fiction", "2009");
        compositionList.add(composition);

        composition = new Composition("The LEGO Composition", "Animation", "2014");
        compositionList.add(composition);

        composition = new Composition("Iron Man", "Action & Adventure", "2008");
        compositionList.add(composition);

        composition = new Composition("Aliens", "Science Fiction", "1986");
        compositionList.add(composition);

        composition = new Composition("Chicken Run", "Animation", "2000");
        compositionList.add(composition);

        composition = new Composition("Back to the Future", "Science Fiction", "1985");
        compositionList.add(composition);

        composition = new Composition("Raiders of the Lost Ark", "Action & Adventure", "1981");
        compositionList.add(composition);

        composition = new Composition("Goldfinger", "Action & Adventure", "1965");
        compositionList.add(composition);

        composition = new Composition("Guardians of the Galaxy", "Science Fiction & Fantasy", "2014");
        compositionList.add(composition);

        // notify adapter about data set changes
        // so that it will render the list with new data
        mAdapter.notifyDataSetChanged();
    }

}
